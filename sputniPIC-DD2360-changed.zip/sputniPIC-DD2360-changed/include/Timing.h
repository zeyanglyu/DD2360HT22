#ifndef TIMING_H
#define TIMING_H

#include <sys/time.h>

// return time in second
double cpuSecond();

#endif
